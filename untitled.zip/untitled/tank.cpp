#include "tank.h"
#include "world.h"
#include <QPainter>
#include <QApplication>

void Tank::move(int direction, int steps){
    QPainter *pa;
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            //this->showup(pa);
            break;
        case -1:
            this->_pos_y += steps;
            //this->showdown(pa);
            break;
        case 2:  
            this->_pos_x -= steps;
            //this->showleft(pa);
            break;
        case -2:
            this->_pos_x += steps;
            //this->showright(pa);
            break;
    }
}

void Tank::showup(QPainter *pa){
    this->p.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    int gSize = ICON::GRID_SIZE;
    p=p.copy(QRect(0,256,64,64));
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->p);
}

/*void Tank::showdown(QPainter *pa){
    this->p.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    int gSize = ICON::GRID_SIZE;
    p=p.copy(QRect(0,384,64,64));
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->p);
}

void Tank::showleft(QPainter *pa){
    this->p.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    int gSize = ICON::GRID_SIZE;
    p=p.copy(QRect(0,448,64,64));
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->p);
}

void Tank::showright(QPainter *pa){
    this->p.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    int gSize = ICON::GRID_SIZE;
    p=p.copy(QRect(0,320,64,64));
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->p);
}*/

/*void Tank::showuup(QPainter *pa){
    this->p.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    int gSize = ICON::GRID_SIZE;
    p=p.copy(QRect(128,256,64,64));
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->p);
}*/
