#include "tank.h"
#include "world.h"
#include <QPainter>
#include <QApplication>
//#include <iostream>
//using namespace std;

void Tank::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            this->showup();
            tankdir=1;
            break;
        case 2:
            this->_pos_y += steps;
            this->showdown();
            tankdir=2;
            break;
        case 3:
            this->_pos_x -= steps;
            this->showleft();
            tankdir=3;
            break;
        case 4:
            this->_pos_x += steps;
            this->showright();
            tankdir=4;
            break;
    }
}

void Tank::showup(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(0,256,64,64));
}

void Tank::showdown(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(0,384,64,64));
}

void Tank::showleft(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(0,448,64,64));
}

void Tank::showright(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(0,320,64,64));
}
