#ifndef ENEMY_H
#define ENEMY_H
#include "rpgobj.h"
#include <QPainter>
#include <QImage>

class Enemy:public RPGObj
{
public:
    Enemy(){}
    ~Enemy(){}
    void Move(int direction, int steps=1);

    void Showup();
    void Showdown();
    void Showleft();
    void Showright();
    int Getdir(){return Tankdir;}

private:
    int Tankdir;
};

#endif // ENEMY_H
