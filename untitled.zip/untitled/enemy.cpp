#include "enemy.h"
#include "world.h"
#include <QPainter>
#include <QApplication>

void Enemy::Move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            this->_pos_y -= steps;
            this->Showup();
            //tankdir=1;
            break;
        case 2:
            this->_pos_y += steps;
            this->_pos_y += steps;
            this->Showdown();
            //tankdir=-1;
            break;
        case 3:
            this->_pos_x -= steps;
            this->_pos_x -= steps;
            this->Showleft();
            //tankdir=2;
            break;
        case 4:
            this->_pos_x += steps;
            this->_pos_x += steps;
            this->Showright();
            //tankdir=-2;
            break;
    }
}

void Enemy::Showup(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(128,256,64,64));
}

void Enemy::Showdown(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(128,384,64,64));
}

void Enemy::Showleft(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(128,448,64,64));
}

void Enemy::Showright(){
    this->_pic.load("C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    _pic=_pic.copy(QRect(128,320,64,64));
}
