#ifndef TANK_H
#define TANK_H
#include "rpgobj.h"
#include <QPainter>
#include <QImage>

class Tank: public RPGObj
{
public:
    Tank(){}
    ~Tank(){}
    void move(int direction, int steps=1);

    void showup(QPainter *pa);
    /*void showdown(QPainter *pa);
    void showleft(QPainter *pa);
    void showright(QPainter *pa);*/
    void showuup(QPainter *pa);

private:
    QImage p;
};

#endif // TANK_H
