#ifndef TANK_H
#define TANK_H
#include "rpgobj.h"
#include <QPainter>
#include <QImage>

class Tank: public RPGObj
{
public:
    Tank(){}
    ~Tank(){}
    void move(int direction, int steps=1);

    void showup();
    void showdown();
    void showleft();
    void showright();
    int getdir(){return tankdir;}

private:
    int tankdir;
};

#endif // TANK_H
