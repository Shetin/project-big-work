#include "world.h"
#include "icon.h"
#include "string"
#include "rpgobj.h"
#include <fstream>
#include <vector>
#include "math.h"

int flag=0;

void World::initWorld(string mapFile){
    //TODO 下面这部分逻辑应该是读入地图文件，生成地图上的对象
    //player 5 5
    this->_tank.initObj("playerTank","C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    this->_tank.setPosX(5);
    this->_tank.setPosY(5);

    RPGObj obj1;
    ifstream inf;
    inf.open(mapFile.c_str());
    string a,p;
    int b,c;
    while(inf >> a){
        inf >>p;
        inf >> b;
        inf >> c;
        obj1.initObj(a,p);
        obj1.setPosX(b);
        obj1.setPosY(c);
        this->_objs.push_back(obj1);
    }
}

void World::show(QPainter * painter){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
    this->_tank.show(painter);
    vector<Enemy>::iterator it1;
    for(it1=this->_enemy.begin();it1!=this->_enemy.end();it1++){
        (*it1).show(painter);
    }
}

void World::handleTankMove(int direction, int steps){
    this->_tank.move(direction, steps);
    this->act(direction, steps);
}

void World::handleEnemyMove(int direction, int steps){
    vector<Enemy>::iterator it;
    for(it = this->_enemy.begin(); it != this->_enemy.end(); it++){
        direction=1 + rand()%4;
        (*it).Move(direction, steps);
    }
    //this->act(direction, steps);
}

void World::act(int direction, int steps){
    vector<RPGObj>::iterator it;
    for(it = this->_objs.begin(); it != this->_objs.end(); it++){
        flag=0;
        if(
            (abs(this->_tank.getPosX()-(*it).getPosX())<2)//(*it).getWidth())
           &&(abs(this->_tank.getPosY()-(*it).getPosY())<2)//(*it).getHeight())
           )

        {
            if((*it).canEat() == true)
            {

             this->_objs.erase(it);

            }
            if((*it).canCover() == false)
            {
               this->_tank.move(direction, -1);
               break;
            }
            if((*it).canCover()==true)
            {
                flag=1;
            }
        }
        if(it == this->_objs.end()) {
            break;
        }
    }
}

void World::addenemy(){
    Enemy enemy;
    enemy.initObj("EnemyTank","C:\\Users\\12267\\Desktop\\TANKWAR\\tank.png");
    enemy.setPosX(3);
    enemy.setPosY(3);
    this->_enemy.push_back(enemy);
}
